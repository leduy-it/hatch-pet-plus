# Intern Discord identity kit

A reusable Discord identity kit for **Intern**, using Bunny as the current visual baseline and backup mascot. The character keeps its periwinkle fur, cream muzzle and belly, pink inner ears, amber eyes, and two buck teeth. The artwork is pixel art with a limited palette and no lettering.

Read [BRAND.md](BRAND.md) for the company name and philosophy, and [REQUIREMENTS.md](REQUIREMENTS.md) for the project checklist and current completion state.

## Files

- `server-icon.png` — 512×512 transparent server icon.
- `bunny-avatar.png` — 512×512 transparent member avatar; the same emblem works for the server icon and avatar.
- `stickers/bunny-wave.png` — 320×320 waving sticker.
- `stickers/bunny-work.png` — 320×320 working sticker.
- `stickers/bunny-question.png` — 320×320 curious/question sticker.
- `stickers/bunny-celebrate.png` — 320×320 celebration sticker.
- `source/` — full-size transparent source art for re-exporting later.
- `PROMPTS.md` — the character lock and image prompts used for this kit.

## Reuse for another server

1. Reuse `server-icon.png`, `bunny-avatar.png`, and the sticker PNGs as-is if the server should share the Bunny identity.
2. If the new server needs another mascot, generate a square transparent emblem and matching transparent sticker poses, preserving the new character's identity in each prompt. Save them in a sibling `source/` folder using the same filenames.
3. Run the exporter from the repository root:

   ```bash
   python3 -m pip install pillow
   python3 scripts/prepare_discord_assets.py \
     --input-dir assets/discord/<server-slug>/source \
     --output-dir assets/discord/<server-slug>
   ```

4. Upload the icon in **Server Settings → Overview → Server Icon**. Add the PNGs in **Server Settings → Stickers** when the server has permission to manage stickers.

The exporter centers transparent art on a square canvas and creates Discord-sized PNGs. Keep the source image files so later exports stay consistent.
