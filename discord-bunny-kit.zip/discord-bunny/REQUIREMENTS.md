# Discord identity project requirements

## Brand

- [x] Company name: **Intern**.
- [x] Brand slogan: **Ask. Learn. Remember.**
- [x] Preserve the idea that people keep learning like interns after they have moved beyond the intern role.
- [x] Keep the brand simple and minimalist, with an upward-looking tone when introducing companies.
- [x] Keep the phrase “unplug intern” as an unresolved private note until its intended meaning is clear.

## Mascot and assets

- [x] Use the existing Bunny in-house pet as the current baseline and backup mascot.
- [x] Keep the existing Bunny source art and Discord assets available for reuse.
- [x] Provide a Discord server icon and avatar artwork plus stickers for waving, working, asking a question, and celebrating.
- [x] Create sticker art through the in-house asset workflow, retain its source, and export it for the platform.
- [x] Keep the existing palette and recognizable Bunny features consistent across the kit.
- [ ] Explore a secondary mascot in the in-house pet style only if it has a clear purpose.
- [ ] Compare any new mascot against Bunny and adopt it only if it is clearly better; otherwise retain Bunny as the fallback.

## Discord setup

- [x] Rename the existing Discord server to **Intern**.
- [x] Keep the server's `#work`, `#learning`, and `#ask-anything` rooms available.
- [x] Upload the server icon and four stickers to the existing server.
- [ ] Save the member avatar in the Discord profile editor after the pending hCaptcha is completed by the account owner.

## Reuse and delivery

- [x] Include source artwork, prompts, and an exporter so the kit can be adapted for another Discord server.
- [x] Publish the reusable kit archive in the `leduy-it/hatch-pet-plus` GitHub repository.
- [ ] When the next server is created, adapt the kit without replacing or losing the Bunny backup.
