#!/usr/bin/env python3
"""Normalize transparent mascot artwork into Discord icon and sticker sizes."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image


ICON_SIZE = 512
STICKER_SIZE = 320


def fit_transparent(source: Path, destination: Path, size: int, margin: float = 0.05) -> None:
    image = Image.open(source).convert("RGBA")
    alpha_bounds = image.getchannel("A").getbbox()
    if alpha_bounds is None:
        raise ValueError(f"{source} has no visible pixels")

    image = image.crop(alpha_bounds)
    max_edge = max(1, int(size * (1 - margin * 2)))
    scale = min(max_edge / image.width, max_edge / image.height)
    new_size = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
    image = image.resize(new_size, Image.Resampling.LANCZOS)

    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    offset = ((size - image.width) // 2, (size - image.height) // 2)
    canvas.alpha_composite(image, offset)
    destination.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(destination, "PNG", optimize=True, compress_level=9)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=Path("source"))
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    parser.add_argument("--prefix", default="bunny", help="Filename prefix for the mascot assets")
    args = parser.parse_args()

    icon_source = args.input_dir / f"{args.prefix}-avatar.png"
    fit_transparent(icon_source, args.output_dir / f"{args.prefix}-avatar.png", ICON_SIZE, margin=0.04)
    fit_transparent(icon_source, args.output_dir / "server-icon.png", ICON_SIZE, margin=0.04)

    for name in ("wave", "work", "question", "celebrate"):
        source = args.input_dir / f"{args.prefix}-{name}.png"
        fit_transparent(source, args.output_dir / "stickers" / f"{args.prefix}-{name}.png", STICKER_SIZE, margin=0.04)

    print(f"Prepared Discord assets in {args.output_dir}")


if __name__ == "__main__":
    main()
