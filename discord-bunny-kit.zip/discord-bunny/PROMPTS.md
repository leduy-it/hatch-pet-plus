# Bunny identity and generation prompts

## Character lock

Use the Bunny from `pets/bunny/base.png` as the identity reference: periwinkle/cornflower blue fur; cream muzzle, cheek ruff, chest and belly; tall upright ears with soft pink inner ears; large amber-brown eyes with a white sparkle; small pink nose; two tiny white buck teeth; cheerful expression; chibi proportions. Do not add clothing, accessories, or brand marks. Keep dark navy pixel outlines and a restrained pixel-art palette.

## Emblem prompt

Create an original square Discord emblem from the Bunny reference. Use a close head-and-shoulders portrait, centered and readable at small icon size. Preserve the character lock exactly. Use carefully composed retro pixel art with deliberate chunky clusters, crisp edges, restrained shading, and no gradients, glow, blur, 3D, photorealism, lettering, or watermark. A simple indigo badge outline may sit behind the head. Keep the outside transparent.

## Sticker prompts

Use the Bunny reference and approved emblem as character and palette references. Keep the exact face, colors, proportions, pixel clusters, and dark outline. Draw one centered full-body pose on a transparent square canvas, with a single clean white die-cut border and no text:

- **Wave:** raise one paw in a friendly wave and tilt the head slightly.
- **Work:** sit attentively beside a small, plain laptop with no logo.
- **Question:** sit upright with one paw raised and a curious head tilt; use only a small question-mark accent.
- **Celebrate:** lift both paws, smile, and add a few palette-matched confetti pieces.

For all poses, avoid stray background texture, fuzzy glow, gradients, soft blur, 3D rendering, photo texture, extra limbs, duplicate characters, and unrelated props.
