# Intern

## Company name

**Intern**

## Meaning and philosophy

Intern is a creative play on the word *intern*: a person can move beyond the intern role and still approach new work with an intern's curiosity. The company philosophy is to keep learning broadly, stay open to discovery, and make things simple and minimal.

When introducing companies, the brand should feel **upward-looking and ascendant**: each introduction should suggest learning, progress, and room to grow without adding ornamental complexity.

The phrase “unplug intern” was supplied as part of the name explanation. Its intended wordplay is not yet clear, so retain it as a private source note and do not use it as public-facing copy until its meaning is confirmed.

## Visual direction

- Simple shapes and a restrained palette.
- Minimal composition with clear hierarchy.
- Curious, capable, and approachable rather than juvenile.
- A sense of progress or upward movement used sparingly.
- No unnecessary decoration, gradients, or effects that make small Discord assets harder to read.

## Mascot direction

Bunny is the existing in-house pet and remains the fallback mascot. Keep its source artwork and current Discord kit intact. A secondary mascot may be explored later in the same in-house pet style, but generate and adopt a candidate only when it is clearly better suited to Intern than Bunny. Do not replace Bunny merely for novelty.
